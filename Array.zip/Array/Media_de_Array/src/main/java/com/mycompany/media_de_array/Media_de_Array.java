/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.media_de_array;

/**
 *
 * @author gabri
 */
import java.util.Scanner;
public class Media_de_Array {

        public static void main(String[] args) {
        try (Scanner scanner = new Scanner (System.in)){
           
            //double[] = cria uma variável do tipo double (real) e os [] indicam que será um array
            //new double = cria a array de double e armazena nela os dados da variável colocados em []
            int tamanhoArray = 20;
            double[] criacaoDeArray = new double[tamanhoArray];
            
            System.out.println("Digite os elementos do Array: \n");
            for (int Elementos = 0; Elementos < tamanhoArray; Elementos++) {
                criacaoDeArray[Elementos] = scanner.nextDouble();
            }
            
            //Após os dois pontos, será informado a array que o código deverá percorrer neste loop (for). Array iterado
            //O operador += seria o mesmo que: soma = soma + itemArray, ambas escritas estão corretas
            double soma = 0;
            for (double itemArray : criacaoDeArray){
                soma += itemArray;
            }
            
            double media = soma / tamanhoArray;
            System.out.println("A média dos elementos deste Array é: " + media);
            System.out.println("Os valores desta Array menores que a média: ");
                    
            for (double itemArray : criacaoDeArray){
                if(itemArray < media ){
                    System.out.println(itemArray);
                }
            }          
    }
}
}
