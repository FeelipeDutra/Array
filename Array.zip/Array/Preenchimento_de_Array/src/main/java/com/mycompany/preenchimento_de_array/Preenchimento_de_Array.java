/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.preenchimento_de_array;

/**
 *
 * @author gabri
 */
import java.util.Scanner;
public class Preenchimento_de_Array {

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner (System.in)){
           
            int tamanhoArray = 10 ;
            
            //int[] = cria uma variável do tipo int e os [] indicam que será um array
            //new int = cria a array de int e armazena nela os dados da variável colocados em []
            int[] criacaoDeArray = new int[tamanhoArray];
            
            System.out.println("Digite os elementos do Array: \n");
            for (int Elementos = 0; Elementos < tamanhoArray; Elementos++) {
                criacaoDeArray[Elementos] = scanner.nextInt();
            }
    }
}
}
